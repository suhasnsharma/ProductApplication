package com.product.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.product.model.Product;
import com.product.service.ProductService;

@RestController
@CrossOrigin(origins = "*")
public class ProductController {

	@Autowired
	private ProductService productService;

	@GetMapping("/products")
	public ResponseEntity<?> getAllProducts() {
		List<Product> products = productService.getAllProducts();
		return ResponseEntity.ok(products);
	}

	@GetMapping("/product/{id}")
	public ResponseEntity<?> getProductById(@PathVariable String id) {
		Optional<Product> product = productService.getProductById(Long.parseLong(id));
		return ResponseEntity.ok(product);
	}

	@DeleteMapping("/product/{id}")
	public ResponseEntity<?> deleteProductById(@PathVariable String id) {
		productService.deleteProductById(Long.parseLong(id));
		return ResponseEntity.ok("success");
	}

	@PutMapping("/product/{id}")
	public ResponseEntity<?> updateProductById(@RequestBody Product product, @PathVariable String id) {
		int res = productService.updateProductById(Long.parseLong(id), product);
		if (res > 0) {
			return ResponseEntity.ok("success");
		} else {
			return ResponseEntity.ok("error");
		}
	}

	@PostMapping("/products")
	public ResponseEntity<?> createProduct(@RequestBody Product product) {
		Product newProduct = productService.createProduct(product);
		if (newProduct != null) {
			return ResponseEntity.ok("success");
		} else {
			return ResponseEntity.ok("error");
		}

	}
}
