package com.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.dao.ProductRepository;
import com.product.model.Product;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Override
	public List<Product> getAllProducts() {
		return productRepository.findAll();
	}

	@Override
	public Optional<Product> getProductById(long id) {
		return productRepository.findById(id);
	}

	@Override
	public int updateProductById(long id, Product product) {

		return productRepository.updateProductById(id, product.getDescription(), product.getPrice());
	}

	@Override
	public void deleteProductById(long id) {
		productRepository.deleteById(id);

	}

	@Override
	public Product createProduct(Product product) {
		return productRepository.save(product);
	}

}
