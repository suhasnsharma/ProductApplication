package com.product.service;

import java.util.List;
import java.util.Optional;

import com.product.model.Product;

public interface ProductService {

	List<Product> getAllProducts();

	Optional<Product> getProductById(long id);

	int updateProductById(long id, Product product);

	void deleteProductById(long id);

	Product createProduct(Product product);

}
